﻿Public Class Form1
    Private Sub cmbOperations_SelectedIndexChanged(sender As Object, e As EventArgs) Handles cmbOperations.SelectedIndexChanged

    End Sub
End Class