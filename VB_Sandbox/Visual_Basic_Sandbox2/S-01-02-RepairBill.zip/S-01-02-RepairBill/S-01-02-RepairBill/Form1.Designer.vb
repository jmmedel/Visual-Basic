﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmRepairBill
  Inherits System.Windows.Forms.Form

  'Form overrides dispose to clean up the component list.
  <System.Diagnostics.DebuggerNonUserCode()> _
  Protected Overrides Sub Dispose(ByVal disposing As Boolean)
    Try
      If disposing AndAlso components IsNot Nothing Then
        components.Dispose()
      End If
    Finally
      MyBase.Dispose(disposing)
    End Try
  End Sub

  'Required by the Windows Form Designer
  Private components As System.ComponentModel.IContainer

  'NOTE: The following procedure is required by the Windows Form Designer
  'It can be modified using the Windows Form Designer.  
  'Do not modify it using the code editor.
  <System.Diagnostics.DebuggerStepThrough()> _
  Private Sub InitializeComponent()
    Me.txtParts = New System.Windows.Forms.MaskedTextBox()
    Me.txtLabor = New System.Windows.Forms.MaskedTextBox()
    Me.btnDisplay = New System.Windows.Forms.Button()
    Me.lstDisplay = New System.Windows.Forms.ListBox()
    Me.txtName = New System.Windows.Forms.TextBox()
    Me.Label3 = New System.Windows.Forms.Label()
    Me.Label2 = New System.Windows.Forms.Label()
    Me.Label1 = New System.Windows.Forms.Label()
    Me.SuspendLayout()
    '
    'txtParts
    '
    Me.txtParts.Location = New System.Drawing.Point(134, 84)
    Me.txtParts.Name = "txtParts"
    Me.txtParts.Size = New System.Drawing.Size(100, 20)
    Me.txtParts.TabIndex = 14
    '
    'txtLabor
    '
    Me.txtLabor.Location = New System.Drawing.Point(134, 44)
    Me.txtLabor.Name = "txtLabor"
    Me.txtLabor.Size = New System.Drawing.Size(100, 20)
    Me.txtLabor.TabIndex = 13
    '
    'btnDisplay
    '
    Me.btnDisplay.Location = New System.Drawing.Point(262, 44)
    Me.btnDisplay.Name = "btnDisplay"
    Me.btnDisplay.Size = New System.Drawing.Size(75, 54)
    Me.btnDisplay.TabIndex = 16
    Me.btnDisplay.Text = "Display Bill"
    Me.btnDisplay.UseVisualStyleBackColor = True
    '
    'lstDisplay
    '
    Me.lstDisplay.FormattingEnabled = True
    Me.lstDisplay.Location = New System.Drawing.Point(134, 133)
    Me.lstDisplay.Name = "lstDisplay"
    Me.lstDisplay.Size = New System.Drawing.Size(203, 95)
    Me.lstDisplay.TabIndex = 15
    '
    'txtName
    '
    Me.txtName.Location = New System.Drawing.Point(134, 11)
    Me.txtName.Name = "txtName"
    Me.txtName.Size = New System.Drawing.Size(203, 20)
    Me.txtName.TabIndex = 12
    '
    'Label3
    '
    Me.Label3.AutoSize = True
    Me.Label3.Location = New System.Drawing.Point(41, 91)
    Me.Label3.Name = "Label3"
    Me.Label3.Size = New System.Drawing.Size(67, 13)
    Me.Label3.TabIndex = 11
    Me.Label3.Text = "Cost of Parts"
    '
    'Label2
    '
    Me.Label2.AutoSize = True
    Me.Label2.Location = New System.Drawing.Point(31, 51)
    Me.Label2.Name = "Label2"
    Me.Label2.Size = New System.Drawing.Size(77, 13)
    Me.Label2.TabIndex = 10
    Me.Label2.Text = "Hours of Labor"
    '
    'Label1
    '
    Me.Label1.AutoSize = True
    Me.Label1.Location = New System.Drawing.Point(26, 18)
    Me.Label1.Name = "Label1"
    Me.Label1.Size = New System.Drawing.Size(82, 13)
    Me.Label1.TabIndex = 9
    Me.Label1.Text = "Customer Name"
    '
    'frmRepairBill
    '
    Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
    Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
    Me.ClientSize = New System.Drawing.Size(379, 247)
    Me.Controls.Add(Me.txtParts)
    Me.Controls.Add(Me.txtLabor)
    Me.Controls.Add(Me.btnDisplay)
    Me.Controls.Add(Me.lstDisplay)
    Me.Controls.Add(Me.txtName)
    Me.Controls.Add(Me.Label3)
    Me.Controls.Add(Me.Label2)
    Me.Controls.Add(Me.Label1)
    Me.Name = "frmRepairBill"
    Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
    Me.Text = "Repair Bill"
    Me.ResumeLayout(False)
    Me.PerformLayout()

  End Sub

  Friend WithEvents txtParts As MaskedTextBox
  Friend WithEvents txtLabor As MaskedTextBox
  Friend WithEvents btnDisplay As Button
  Friend WithEvents lstDisplay As ListBox
  Friend WithEvents txtName As TextBox
  Friend WithEvents Label3 As Label
  Friend WithEvents Label2 As Label
  Friend WithEvents Label1 As Label
End Class
