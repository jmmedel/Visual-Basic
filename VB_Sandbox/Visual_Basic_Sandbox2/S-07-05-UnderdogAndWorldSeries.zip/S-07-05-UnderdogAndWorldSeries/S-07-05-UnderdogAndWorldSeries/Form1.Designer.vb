﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmUnderdogWorldSeries
  Inherits System.Windows.Forms.Form

  'Form overrides dispose to clean up the component list.
  <System.Diagnostics.DebuggerNonUserCode()> _
  Protected Overrides Sub Dispose(ByVal disposing As Boolean)
    Try
      If disposing AndAlso components IsNot Nothing Then
        components.Dispose()
      End If
    Finally
      MyBase.Dispose(disposing)
    End Try
  End Sub

  'Required by the Windows Form Designer
  Private components As System.ComponentModel.IContainer

  'NOTE: The following procedure is required by the Windows Form Designer
  'It can be modified using the Windows Form Designer.  
  'Do not modify it using the code editor.
  <System.Diagnostics.DebuggerStepThrough()> _
  Private Sub InitializeComponent()
    Me.txtProb = New System.Windows.Forms.TextBox()
    Me.txtAverageDuration = New System.Windows.Forms.TextBox()
    Me.txtFourPercent = New System.Windows.Forms.TextBox()
    Me.txtSeven = New System.Windows.Forms.TextBox()
    Me.txtSix = New System.Windows.Forms.TextBox()
    Me.txtFive = New System.Windows.Forms.TextBox()
    Me.txtFour = New System.Windows.Forms.TextBox()
    Me.txtSevenPercent = New System.Windows.Forms.TextBox()
    Me.txtSixPercent = New System.Windows.Forms.TextBox()
    Me.txtFivePercent = New System.Windows.Forms.TextBox()
    Me.txtFavoritePercent = New System.Windows.Forms.TextBox()
    Me.txtFavorite = New System.Windows.Forms.TextBox()
    Me.txtUnderdogPercent = New System.Windows.Forms.TextBox()
    Me.txtUnderdog = New System.Windows.Forms.TextBox()
    Me.hsbSeven = New System.Windows.Forms.HScrollBar()
    Me.hsbSix = New System.Windows.Forms.HScrollBar()
    Me.hsbFive = New System.Windows.Forms.HScrollBar()
    Me.hsbFour = New System.Windows.Forms.HScrollBar()
    Me.hsbUnderdog = New System.Windows.Forms.HScrollBar()
    Me.hsbFavorite = New System.Windows.Forms.HScrollBar()
    Me.Label11 = New System.Windows.Forms.Label()
    Me.Label10 = New System.Windows.Forms.Label()
    Me.Label9 = New System.Windows.Forms.Label()
    Me.Label8 = New System.Windows.Forms.Label()
    Me.Label7 = New System.Windows.Forms.Label()
    Me.Label6 = New System.Windows.Forms.Label()
    Me.Label5 = New System.Windows.Forms.Label()
    Me.Label4 = New System.Windows.Forms.Label()
    Me.Label3 = New System.Windows.Forms.Label()
    Me.Label2 = New System.Windows.Forms.Label()
    Me.Label1 = New System.Windows.Forms.Label()
    Me.btnSimulate = New System.Windows.Forms.Button()
    Me.SuspendLayout
    '
    'txtProb
    '
    Me.txtProb.Location = New System.Drawing.Point(178, 27)
    Me.txtProb.Name = "txtProb"
    Me.txtProb.Size = New System.Drawing.Size(32, 20)
    Me.txtProb.TabIndex = 33
    '
    'txtAverageDuration
    '
    Me.txtAverageDuration.Location = New System.Drawing.Point(374, 311)
    Me.txtAverageDuration.Margin = New System.Windows.Forms.Padding(4, 3, 4, 3)
    Me.txtAverageDuration.Name = "txtAverageDuration"
    Me.txtAverageDuration.ReadOnly = true
    Me.txtAverageDuration.Size = New System.Drawing.Size(82, 20)
    Me.txtAverageDuration.TabIndex = 63
    '
    'txtFourPercent
    '
    Me.txtFourPercent.Location = New System.Drawing.Point(593, 183)
    Me.txtFourPercent.Margin = New System.Windows.Forms.Padding(4, 3, 4, 3)
    Me.txtFourPercent.Name = "txtFourPercent"
    Me.txtFourPercent.ReadOnly = true
    Me.txtFourPercent.Size = New System.Drawing.Size(52, 20)
    Me.txtFourPercent.TabIndex = 49
    '
    'txtSeven
    '
    Me.txtSeven.Location = New System.Drawing.Point(514, 279)
    Me.txtSeven.Margin = New System.Windows.Forms.Padding(4, 0, 4, 3)
    Me.txtSeven.Multiline = true
    Me.txtSeven.Name = "txtSeven"
    Me.txtSeven.ReadOnly = true
    Me.txtSeven.Size = New System.Drawing.Size(52, 20)
    Me.txtSeven.TabIndex = 60
    '
    'txtSix
    '
    Me.txtSix.Location = New System.Drawing.Point(514, 247)
    Me.txtSix.Margin = New System.Windows.Forms.Padding(4, 3, 1, 0)
    Me.txtSix.Multiline = true
    Me.txtSix.Name = "txtSix"
    Me.txtSix.ReadOnly = true
    Me.txtSix.Size = New System.Drawing.Size(52, 20)
    Me.txtSix.TabIndex = 56
    '
    'txtFive
    '
    Me.txtFive.Location = New System.Drawing.Point(514, 215)
    Me.txtFive.Margin = New System.Windows.Forms.Padding(4, 3, 1, 3)
    Me.txtFive.Name = "txtFive"
    Me.txtFive.ReadOnly = true
    Me.txtFive.Size = New System.Drawing.Size(52, 20)
    Me.txtFive.TabIndex = 52
    '
    'txtFour
    '
    Me.txtFour.Location = New System.Drawing.Point(514, 183)
    Me.txtFour.Margin = New System.Windows.Forms.Padding(4, 3, 4, 3)
    Me.txtFour.Name = "txtFour"
    Me.txtFour.ReadOnly = true
    Me.txtFour.Size = New System.Drawing.Size(52, 20)
    Me.txtFour.TabIndex = 48
    '
    'txtSevenPercent
    '
    Me.txtSevenPercent.Location = New System.Drawing.Point(593, 279)
    Me.txtSevenPercent.Margin = New System.Windows.Forms.Padding(4, 3, 4, 3)
    Me.txtSevenPercent.Name = "txtSevenPercent"
    Me.txtSevenPercent.ReadOnly = true
    Me.txtSevenPercent.Size = New System.Drawing.Size(52, 20)
    Me.txtSevenPercent.TabIndex = 61
    '
    'txtSixPercent
    '
    Me.txtSixPercent.Location = New System.Drawing.Point(593, 247)
    Me.txtSixPercent.Margin = New System.Windows.Forms.Padding(1, 3, 4, 3)
    Me.txtSixPercent.Name = "txtSixPercent"
    Me.txtSixPercent.ReadOnly = true
    Me.txtSixPercent.Size = New System.Drawing.Size(52, 20)
    Me.txtSixPercent.TabIndex = 57
    '
    'txtFivePercent
    '
    Me.txtFivePercent.Location = New System.Drawing.Point(593, 215)
    Me.txtFivePercent.Margin = New System.Windows.Forms.Padding(1, 3, 4, 3)
    Me.txtFivePercent.Name = "txtFivePercent"
    Me.txtFivePercent.ReadOnly = true
    Me.txtFivePercent.Size = New System.Drawing.Size(52, 20)
    Me.txtFivePercent.TabIndex = 53
    '
    'txtFavoritePercent
    '
    Me.txtFavoritePercent.Location = New System.Drawing.Point(593, 122)
    Me.txtFavoritePercent.Margin = New System.Windows.Forms.Padding(4, 3, 4, 3)
    Me.txtFavoritePercent.Name = "txtFavoritePercent"
    Me.txtFavoritePercent.ReadOnly = true
    Me.txtFavoritePercent.Size = New System.Drawing.Size(52, 20)
    Me.txtFavoritePercent.TabIndex = 44
    '
    'txtFavorite
    '
    Me.txtFavorite.Location = New System.Drawing.Point(514, 122)
    Me.txtFavorite.Margin = New System.Windows.Forms.Padding(4, 3, 4, 3)
    Me.txtFavorite.Name = "txtFavorite"
    Me.txtFavorite.ReadOnly = true
    Me.txtFavorite.Size = New System.Drawing.Size(52, 20)
    Me.txtFavorite.TabIndex = 43
    '
    'txtUnderdogPercent
    '
    Me.txtUnderdogPercent.Location = New System.Drawing.Point(593, 81)
    Me.txtUnderdogPercent.Margin = New System.Windows.Forms.Padding(4, 3, 4, 3)
    Me.txtUnderdogPercent.Name = "txtUnderdogPercent"
    Me.txtUnderdogPercent.ReadOnly = true
    Me.txtUnderdogPercent.Size = New System.Drawing.Size(52, 20)
    Me.txtUnderdogPercent.TabIndex = 40
    '
    'txtUnderdog
    '
    Me.txtUnderdog.Location = New System.Drawing.Point(514, 81)
    Me.txtUnderdog.Margin = New System.Windows.Forms.Padding(4, 3, 4, 3)
    Me.txtUnderdog.Name = "txtUnderdog"
    Me.txtUnderdog.ReadOnly = true
    Me.txtUnderdog.Size = New System.Drawing.Size(52, 20)
    Me.txtUnderdog.TabIndex = 39
    '
    'hsbSeven
    '
    Me.hsbSeven.Location = New System.Drawing.Point(94, 281)
    Me.hsbSeven.Maximum = 10000
    Me.hsbSeven.Name = "hsbSeven"
    Me.hsbSeven.Size = New System.Drawing.Size(399, 17)
    Me.hsbSeven.TabIndex = 59
    '
    'hsbSix
    '
    Me.hsbSix.Location = New System.Drawing.Point(94, 249)
    Me.hsbSix.Maximum = 10000
    Me.hsbSix.Name = "hsbSix"
    Me.hsbSix.Size = New System.Drawing.Size(399, 17)
    Me.hsbSix.TabIndex = 55
    '
    'hsbFive
    '
    Me.hsbFive.Location = New System.Drawing.Point(94, 217)
    Me.hsbFive.Maximum = 10000
    Me.hsbFive.Name = "hsbFive"
    Me.hsbFive.Size = New System.Drawing.Size(399, 17)
    Me.hsbFive.TabIndex = 51
    '
    'hsbFour
    '
    Me.hsbFour.Location = New System.Drawing.Point(94, 185)
    Me.hsbFour.Maximum = 10000
    Me.hsbFour.Name = "hsbFour"
    Me.hsbFour.Size = New System.Drawing.Size(399, 17)
    Me.hsbFour.TabIndex = 47
    '
    'hsbUnderdog
    '
    Me.hsbUnderdog.Location = New System.Drawing.Point(94, 83)
    Me.hsbUnderdog.Maximum = 10000
    Me.hsbUnderdog.Name = "hsbUnderdog"
    Me.hsbUnderdog.Size = New System.Drawing.Size(399, 17)
    Me.hsbUnderdog.TabIndex = 38
    '
    'hsbFavorite
    '
    Me.hsbFavorite.Location = New System.Drawing.Point(94, 119)
    Me.hsbFavorite.Maximum = 10000
    Me.hsbFavorite.Name = "hsbFavorite"
    Me.hsbFavorite.Size = New System.Drawing.Size(399, 17)
    Me.hsbFavorite.TabIndex = 42
    '
    'Label11
    '
    Me.Label11.AutoSize = true
    Me.Label11.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0,Byte))
    Me.Label11.Location = New System.Drawing.Point(220, 158)
    Me.Label11.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
    Me.Label11.Name = "Label11"
    Me.Label11.Size = New System.Drawing.Size(229, 16)
    Me.Label11.TabIndex = 45
    Me.Label11.Text = "DURATION OF WORLD SERIES"
    '
    'Label10
    '
    Me.Label10.AutoSize = true
    Me.Label10.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0,Byte))
    Me.Label10.Location = New System.Drawing.Point(300, 60)
    Me.Label10.Margin = New System.Windows.Forms.Padding(4, 1, 4, 1)
    Me.Label10.Name = "Label10"
    Me.Label10.Size = New System.Drawing.Size(69, 16)
    Me.Label10.TabIndex = 36
    Me.Label10.Text = "WINNER"
    '
    'Label9
    '
    Me.Label9.AutoSize = true
    Me.Label9.Location = New System.Drawing.Point(212, 314)
    Me.Label9.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
    Me.Label9.Name = "Label9"
    Me.Label9.Size = New System.Drawing.Size(161, 13)
    Me.Label9.TabIndex = 62
    Me.Label9.Text = "Average duration of world series:"
    '
    'Label8
    '
    Me.Label8.AutoSize = true
    Me.Label8.Location = New System.Drawing.Point(14, 283)
    Me.Label8.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
    Me.Label8.Name = "Label8"
    Me.Label8.Size = New System.Drawing.Size(75, 13)
    Me.Label8.TabIndex = 58
    Me.Label8.Text = "Seven games:"
    '
    'Label7
    '
    Me.Label7.AutoSize = true
    Me.Label7.Location = New System.Drawing.Point(33, 251)
    Me.Label7.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
    Me.Label7.Name = "Label7"
    Me.Label7.Size = New System.Drawing.Size(58, 13)
    Me.Label7.TabIndex = 54
    Me.Label7.Text = "Six games:"
    '
    'Label6
    '
    Me.Label6.AutoSize = true
    Me.Label6.Location = New System.Drawing.Point(26, 219)
    Me.Label6.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
    Me.Label6.Name = "Label6"
    Me.Label6.Size = New System.Drawing.Size(64, 13)
    Me.Label6.TabIndex = 50
    Me.Label6.Text = "Five games:"
    '
    'Label5
    '
    Me.Label5.AutoSize = true
    Me.Label5.Location = New System.Drawing.Point(23, 187)
    Me.Label5.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
    Me.Label5.Name = "Label5"
    Me.Label5.Size = New System.Drawing.Size(65, 13)
    Me.Label5.TabIndex = 46
    Me.Label5.Text = "Four games:"
    '
    'Label4
    '
    Me.Label4.AutoSize = true
    Me.Label4.Location = New System.Drawing.Point(47, 127)
    Me.Label4.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
    Me.Label4.Name = "Label4"
    Me.Label4.Size = New System.Drawing.Size(48, 13)
    Me.Label4.TabIndex = 41
    Me.Label4.Text = "Favorite:"
    '
    'Label3
    '
    Me.Label3.AutoSize = true
    Me.Label3.Location = New System.Drawing.Point(36, 84)
    Me.Label3.Margin = New System.Windows.Forms.Padding(4, 1, 4, 3)
    Me.Label3.Name = "Label3"
    Me.Label3.Size = New System.Drawing.Size(57, 13)
    Me.Label3.TabIndex = 37
    Me.Label3.Text = "Underdog:"
    '
    'Label2
    '
    Me.Label2.AutoSize = true
    Me.Label2.Location = New System.Drawing.Point(217, 31)
    Me.Label2.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
    Me.Label2.Name = "Label2"
    Me.Label2.Size = New System.Drawing.Size(15, 13)
    Me.Label2.TabIndex = 34
    Me.Label2.Text = "%"
    '
    'Label1
    '
    Me.Label1.Location = New System.Drawing.Point(57, 21)
    Me.Label1.Margin = New System.Windows.Forms.Padding(4, 3, 4, 1)
    Me.Label1.Name = "Label1"
    Me.Label1.Size = New System.Drawing.Size(118, 33)
    Me.Label1.TabIndex = 32
    Me.Label1.Text = "Probability of underdog winning a game:"
    '
    'btnSimulate
    '
    Me.btnSimulate.Location = New System.Drawing.Point(416, 23)
    Me.btnSimulate.Margin = New System.Windows.Forms.Padding(4, 3, 4, 2)
    Me.btnSimulate.Name = "btnSimulate"
    Me.btnSimulate.Size = New System.Drawing.Size(221, 29)
    Me.btnSimulate.TabIndex = 35
    Me.btnSimulate.Text = "Simulate Outcomes of 10,000 World Series"
    '
    'frmUnderdogWorldSeries
    '
    Me.AutoScaleDimensions = New System.Drawing.SizeF(6!, 13!)
    Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
    Me.ClientSize = New System.Drawing.Size(689, 359)
    Me.Controls.Add(Me.txtProb)
    Me.Controls.Add(Me.txtAverageDuration)
    Me.Controls.Add(Me.txtFourPercent)
    Me.Controls.Add(Me.txtSeven)
    Me.Controls.Add(Me.txtSix)
    Me.Controls.Add(Me.txtFive)
    Me.Controls.Add(Me.txtFour)
    Me.Controls.Add(Me.txtSevenPercent)
    Me.Controls.Add(Me.txtSixPercent)
    Me.Controls.Add(Me.txtFivePercent)
    Me.Controls.Add(Me.txtFavoritePercent)
    Me.Controls.Add(Me.txtFavorite)
    Me.Controls.Add(Me.txtUnderdogPercent)
    Me.Controls.Add(Me.txtUnderdog)
    Me.Controls.Add(Me.hsbSeven)
    Me.Controls.Add(Me.hsbSix)
    Me.Controls.Add(Me.hsbFive)
    Me.Controls.Add(Me.hsbFour)
    Me.Controls.Add(Me.hsbUnderdog)
    Me.Controls.Add(Me.hsbFavorite)
    Me.Controls.Add(Me.Label11)
    Me.Controls.Add(Me.Label10)
    Me.Controls.Add(Me.Label9)
    Me.Controls.Add(Me.Label8)
    Me.Controls.Add(Me.Label7)
    Me.Controls.Add(Me.Label6)
    Me.Controls.Add(Me.Label5)
    Me.Controls.Add(Me.Label4)
    Me.Controls.Add(Me.Label3)
    Me.Controls.Add(Me.Label2)
    Me.Controls.Add(Me.Label1)
    Me.Controls.Add(Me.btnSimulate)
    Me.Name = "frmUnderdogWorldSeries"
    Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
    Me.Text = "Underdog And The World Series"
    Me.ResumeLayout(false)
    Me.PerformLayout

End Sub

  Friend WithEvents txtProb As TextBox
  Friend WithEvents txtAverageDuration As TextBox
  Friend WithEvents txtFourPercent As TextBox
  Friend WithEvents txtSeven As TextBox
  Friend WithEvents txtSix As TextBox
  Friend WithEvents txtFive As TextBox
  Friend WithEvents txtFour As TextBox
  Friend WithEvents txtSevenPercent As TextBox
  Friend WithEvents txtSixPercent As TextBox
  Friend WithEvents txtFivePercent As TextBox
  Friend WithEvents txtFavoritePercent As TextBox
  Friend WithEvents txtFavorite As TextBox
  Friend WithEvents txtUnderdogPercent As TextBox
  Friend WithEvents txtUnderdog As TextBox
  Friend WithEvents hsbSeven As HScrollBar
  Friend WithEvents hsbSix As HScrollBar
  Friend WithEvents hsbFive As HScrollBar
  Friend WithEvents hsbFour As HScrollBar
  Friend WithEvents hsbUnderdog As HScrollBar
  Friend WithEvents hsbFavorite As HScrollBar
  Friend WithEvents Label11 As Label
  Friend WithEvents Label10 As Label
  Friend WithEvents Label9 As Label
  Friend WithEvents Label8 As Label
  Friend WithEvents Label7 As Label
  Friend WithEvents Label6 As Label
  Friend WithEvents Label5 As Label
  Friend WithEvents Label4 As Label
  Friend WithEvents Label3 As Label
  Friend WithEvents Label2 As Label
  Friend WithEvents Label1 As Label
  Friend WithEvents btnSimulate As Button
End Class
