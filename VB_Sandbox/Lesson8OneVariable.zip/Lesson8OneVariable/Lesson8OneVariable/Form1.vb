﻿Public Class Form1
    Private Sub TrackBar1_Scroll(sender As Object, e As EventArgs) Handles TrackBar1.Scroll
        'Dim value As Integer = TrackBar1.Value
        Label1.Text = $"Value:{TrackBar1.Value }"
    End Sub
End Class