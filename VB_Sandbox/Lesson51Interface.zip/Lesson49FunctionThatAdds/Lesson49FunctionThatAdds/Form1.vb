﻿Public Class Form1
    Private Sub say()

    End Sub
End Class